import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { PokerEngine } from "./services/poker-engine";
import { TonService } from "./services/ton-service";
import { 
  insertUserSchema, 
  insertPokerTableSchema, 
  insertTransactionSchema,
  insertChatMessageSchema 
} from "@shared/schema";
import { z } from "zod";

// Store active games and WebSocket connections
const activeGames = new Map<string, PokerEngine>();
const gameConnections = new Map<string, Set<WebSocket>>();
const userConnections = new Map<string, WebSocket>();

const tonService = new TonService();

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Serve TonConnect manifest
  app.get('/tonconnect-manifest.json', (req, res) => {
    res.json({
      url: `${req.protocol}://${req.get('host')}`,
      name: "TON Poker Pro",
      iconUrl: `${req.protocol}://${req.get('host')}/icon.png`,
      termsOfUseUrl: `${req.protocol}://${req.get('host')}/terms`,
      privacyPolicyUrl: `${req.protocol}://${req.get('host')}/privacy`
    });
  });

  // WebSocket server for real-time poker updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket, request) => {
    console.log('New WebSocket connection');

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        await handleWebSocketMessage(ws, message);
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({ type: 'error', message: 'Invalid message format' }));
      }
    });

    ws.on('close', () => {
      // Clean up user connection
      for (const [userId, connection] of userConnections.entries()) {
        if (connection === ws) {
          userConnections.delete(userId);
          break;
        }
      }
      
      // Remove from game connections
      for (const [gameId, connections] of gameConnections.entries()) {
        connections.delete(ws);
        if (connections.size === 0) {
          gameConnections.delete(gameId);
        }
      }
    });
  });

  // User authentication and management
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const user = await storage.createUser(userData);
      res.json({ user: { ...user, balance: "0" } });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(400).json({ message: "Registration failed" });
    }
  });

  app.get("/api/user/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.patch("/api/user/:id/wallet", async (req, res) => {
    try {
      const { walletAddress } = req.body;
      await storage.updateUserWallet(req.params.id, walletAddress);
      res.json({ message: "Wallet updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update wallet" });
    }
  });

  // Poker table management
  app.get("/api/tables", async (req, res) => {
    try {
      const tables = await storage.getActiveTables();
      res.json(tables);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tables" });
    }
  });

  app.post("/api/tables", async (req, res) => {
    try {
      const tableData = insertPokerTableSchema.parse(req.body);
      const { createdBy } = req.body;
      
      if (!createdBy) {
        return res.status(400).json({ message: "Creator ID required" });
      }

      const table = await storage.createTable({ ...tableData, createdBy });
      res.json(table);
    } catch (error) {
      console.error('Create table error:', error);
      res.status(400).json({ message: "Failed to create table" });
    }
  });

  app.get("/api/tables/:id", async (req, res) => {
    try {
      const table = await storage.getTable(req.params.id);
      if (!table) {
        return res.status(404).json({ message: "Table not found" });
      }
      res.json(table);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch table" });
    }
  });

  // Game management
  app.post("/api/games/:tableId/join", async (req, res) => {
    try {
      const { tableId } = req.params;
      const { userId, chipCount } = req.body;

      const table = await storage.getTable(tableId);
      if (!table) {
        return res.status(404).json({ message: "Table not found" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user has sufficient balance
      const userBalance = parseFloat(user.balance);
      const requiredChips = parseFloat(chipCount);
      
      if (userBalance < requiredChips) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Find available position
      const participants = await storage.getGameParticipants(tableId);
      const occupiedPositions = participants.map(p => p.position);
      let position = -1;
      
      for (let i = 0; i < table.maxPlayers; i++) {
        if (!occupiedPositions.includes(i)) {
          position = i;
          break;
        }
      }

      if (position === -1) {
        return res.status(400).json({ message: "Table is full" });
      }

      // Get or create active game for this table
      let game = activeGames.get(tableId);
      if (!game) {
        const gameData = await storage.createGame({
          tableId,
          handNumber: 1,
          gameState: 'waiting'
        });
        game = new PokerEngine(gameData.id, storage);
        activeGames.set(tableId, game);
      }

      // Add participant
      const participant = await storage.addParticipant({
        gameId: game.gameId,
        userId,
        position,
        chipCount,
        initialChips: chipCount,
        holeCards: [],
        currentBet: "0",
        totalBet: "0",
        hasActed: false,
        hasFolded: false,
        isAllIn: false
      });

      // Update user balance
      await storage.updateUserBalance(userId, (userBalance - requiredChips).toString());

      // Update table player count
      await storage.updateTablePlayerCount(tableId, participants.length + 1);

      // Add to game if enough players
      await game.addPlayer(userId, position, chipCount);

      // Broadcast table update
      broadcastToGame(tableId, {
        type: 'player_joined',
        participant,
        tableState: await game.getGameState()
      });

      res.json({ participant, gameId: game.gameId });
    } catch (error) {
      console.error('Join game error:', error);
      res.status(500).json({ message: "Failed to join game" });
    }
  });

  app.post("/api/games/:gameId/action", async (req, res) => {
    try {
      const { gameId } = req.params;
      const { userId, action, amount } = req.body;

      const game = activeGames.get(gameId);
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }

      const result = await game.handlePlayerAction(userId, action, amount);
      
      if (!result.success) {
        return res.status(400).json({ message: result.error });
      }

      // Broadcast game update
      broadcastToGame(gameId, {
        type: 'game_update',
        gameState: await game.getGameState(),
        action: {
          userId,
          action,
          amount
        }
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Game action error:', error);
      res.status(500).json({ message: "Failed to process action" });
    }
  });

  // Transaction management
  app.post("/api/transactions", async (req, res) => {
    try {
      const transactionData = insertTransactionSchema.parse(req.body);
      const { userId, gameId } = req.body;

      const transaction = await storage.createTransaction({
        ...transactionData,
        userId,
        gameId
      });

      // Handle different transaction types
      if (transactionData.type === 'deposit') {
        // Process TON deposit
        const depositResult = await tonService.processDeposit(
          transaction.id,
          transactionData.amount,
          userId
        );
        
        if (depositResult.success) {
          await storage.updateTransactionStatus(
            transaction.id, 
            'confirmed', 
            depositResult.txHash
          );
          
          // Update user balance
          const user = await storage.getUser(userId);
          if (user) {
            const newBalance = (parseFloat(user.balance) + parseFloat(transactionData.amount)).toString();
            await storage.updateUserBalance(userId, newBalance);
          }
        }
      } else if (transactionData.type === 'withdrawal') {
        // Process TON withdrawal
        const user = await storage.getUser(userId);
        if (user && user.tonWalletAddress) {
          const withdrawResult = await tonService.processWithdrawal(
            user.tonWalletAddress,
            transactionData.amount,
            transaction.id
          );
          
          if (withdrawResult.success) {
            await storage.updateTransactionStatus(
              transaction.id,
              'confirmed',
              withdrawResult.txHash
            );
            
            // Update user balance
            const newBalance = (parseFloat(user.balance) - parseFloat(transactionData.amount)).toString();
            await storage.updateUserBalance(userId, newBalance);
          }
        }
      }

      res.json(transaction);
    } catch (error) {
      console.error('Transaction error:', error);
      res.status(400).json({ message: "Transaction failed" });
    }
  });

  app.get("/api/user/:userId/transactions", async (req, res) => {
    try {
      const transactions = await storage.getUserTransactions(req.params.userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Chat management
  app.post("/api/games/:gameId/chat", async (req, res) => {
    try {
      const { gameId } = req.params;
      const messageData = insertChatMessageSchema.parse(req.body);
      const { userId } = req.body;

      const message = await storage.addChatMessage({
        ...messageData,
        gameId,
        userId
      });

      // Broadcast chat message
      broadcastToGame(gameId, {
        type: 'chat_message',
        message
      });

      res.json(message);
    } catch (error) {
      console.error('Chat error:', error);
      res.status(400).json({ message: "Failed to send message" });
    }
  });

  app.get("/api/games/:gameId/chat", async (req, res) => {
    try {
      const messages = await storage.getGameChatMessages(req.params.gameId);
      res.json(messages.reverse()); // Return in chronological order
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // WebSocket message handling
  async function handleWebSocketMessage(ws: WebSocket, message: any) {
    switch (message.type) {
      case 'join_game':
        const { gameId, userId } = message;
        userConnections.set(userId, ws);
        
        if (!gameConnections.has(gameId)) {
          gameConnections.set(gameId, new Set());
        }
        gameConnections.get(gameId)!.add(ws);
        
        // Send current game state
        const game = activeGames.get(gameId);
        if (game) {
          ws.send(JSON.stringify({
            type: 'game_state',
            gameState: await game.getGameState()
          }));
        }
        break;

      case 'leave_game':
        // Handle leaving game logic
        break;

      case 'ping':
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'pong' }));
        }
        break;
    }
  }

  // Broadcast message to all connections in a game
  function broadcastToGame(gameId: string, message: any) {
    const connections = gameConnections.get(gameId);
    if (connections) {
      const messageStr = JSON.stringify(message);
      connections.forEach((ws) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(messageStr);
        }
      });
    }
  }

  return httpServer;
}
