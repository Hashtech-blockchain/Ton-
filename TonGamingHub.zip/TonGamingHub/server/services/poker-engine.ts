import { storage, type IStorage } from "../storage";
import { type Card, type GameState, type PlayerAction } from "@shared/schema";

export interface PlayerState {
  id: string;
  position: number;
  chipCount: number;
  holeCards: Card[];
  currentBet: number;
  totalBet: number;
  hasActed: boolean;
  hasFolded: boolean;
  isAllIn: boolean;
}

export interface GameStateData {
  gameId: string;
  tableId: string;
  state: GameState;
  pot: number;
  communityCards: Card[];
  currentPlayer: string | null;
  players: PlayerState[];
  dealerPosition: number;
  smallBlindPosition: number;
  bigBlindPosition: number;
  currentBet: number;
  handNumber: number;
}

export class PokerEngine {
  public gameId: string;
  private storage: IStorage;
  private deck: Card[];
  private communityCards: Card[];
  private pot: number;
  private currentBet: number;
  private players: Map<string, PlayerState>;
  private gameState: GameState;
  private currentPlayerIndex: number;
  private dealerPosition: number;
  private smallBlind: number;
  private bigBlind: number;
  private handNumber: number;

  constructor(gameId: string, storage: IStorage) {
    this.gameId = gameId;
    this.storage = storage;
    this.deck = [];
    this.communityCards = [];
    this.pot = 0;
    this.currentBet = 0;
    this.players = new Map();
    this.gameState = 'waiting';
    this.currentPlayerIndex = 0;
    this.dealerPosition = 0;
    this.smallBlind = 0.1;
    this.bigBlind = 0.2;
    this.handNumber = 1;
  }

  private createDeck(): Card[] {
    const suits = ['♠', '♥', '♦', '♣'];
    const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    const deck: Card[] = [];

    for (const suit of suits) {
      for (const rank of ranks) {
        deck.push({ rank, suit });
      }
    }

    return this.shuffleDeck(deck);
  }

  private shuffleDeck(deck: Card[]): Card[] {
    const shuffled = [...deck];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  private getCardRankValue(rank: string): number {
    const values: { [key: string]: number } = {
      '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
      'J': 11, 'Q': 12, 'K': 13, 'A': 14
    };
    return values[rank] || 0;
  }

  private evaluateHand(cards: Card[]): { strength: number; description: string } {
    // Simplified hand evaluation - in production, use a proper poker hand evaluator
    const sortedCards = cards.sort((a, b) => this.getCardRankValue(b.rank) - this.getCardRankValue(a.rank));
    
    // Check for flush
    const isFlush = cards.every(card => card.suit === cards[0].suit);
    
    // Check for straight
    const ranks = sortedCards.map(card => this.getCardRankValue(card.rank));
    const isStraight = ranks.every((rank, index) => index === 0 || rank === ranks[index - 1] - 1);
    
    // Count ranks
    const rankCounts: { [key: string]: number } = {};
    cards.forEach(card => {
      rankCounts[card.rank] = (rankCounts[card.rank] || 0) + 1;
    });
    
    const counts = Object.values(rankCounts).sort((a, b) => b - a);
    
    // Hand rankings (higher number = better hand)
    if (isStraight && isFlush) {
      return { strength: 8, description: 'Straight Flush' };
    } else if (counts[0] === 4) {
      return { strength: 7, description: 'Four of a Kind' };
    } else if (counts[0] === 3 && counts[1] === 2) {
      return { strength: 6, description: 'Full House' };
    } else if (isFlush) {
      return { strength: 5, description: 'Flush' };
    } else if (isStraight) {
      return { strength: 4, description: 'Straight' };
    } else if (counts[0] === 3) {
      return { strength: 3, description: 'Three of a Kind' };
    } else if (counts[0] === 2 && counts[1] === 2) {
      return { strength: 2, description: 'Two Pair' };
    } else if (counts[0] === 2) {
      return { strength: 1, description: 'One Pair' };
    } else {
      return { strength: 0, description: 'High Card' };
    }
  }

  async addPlayer(userId: string, position: number, chipCount: string): Promise<void> {
    const player: PlayerState = {
      id: userId,
      position,
      chipCount: parseFloat(chipCount),
      holeCards: [],
      currentBet: 0,
      totalBet: 0,
      hasActed: false,
      hasFolded: false,
      isAllIn: false
    };

    this.players.set(userId, player);

    // Start game if we have at least 2 players
    if (this.players.size >= 2 && this.gameState === 'waiting') {
      await this.startNewHand();
    }
  }

  async startNewHand(): Promise<void> {
    this.deck = this.createDeck();
    this.communityCards = [];
    this.pot = 0;
    this.currentBet = 0;
    this.gameState = 'preflop';

    // Reset player states
    for (const player of this.players.values()) {
      player.holeCards = [];
      player.currentBet = 0;
      player.totalBet = 0;
      player.hasActed = false;
      player.hasFolded = false;
      player.isAllIn = false;
    }

    // Deal hole cards
    for (let i = 0; i < 2; i++) {
      for (const player of this.players.values()) {
        if (this.deck.length > 0) {
          player.holeCards.push(this.deck.pop()!);
        }
      }
    }

    // Post blinds
    await this.postBlinds();

    // Update database
    await this.updateGameInDatabase();
  }

  private async postBlinds(): Promise<void> {
    const playerArray = Array.from(this.players.values()).sort((a, b) => a.position - b.position);
    
    if (playerArray.length >= 2) {
      // Small blind
      const smallBlindPlayer = playerArray[this.dealerPosition % playerArray.length];
      smallBlindPlayer.currentBet = this.smallBlind;
      smallBlindPlayer.totalBet = this.smallBlind;
      smallBlindPlayer.chipCount -= this.smallBlind;
      this.pot += this.smallBlind;

      // Big blind
      const bigBlindPlayer = playerArray[(this.dealerPosition + 1) % playerArray.length];
      bigBlindPlayer.currentBet = this.bigBlind;
      bigBlindPlayer.totalBet = this.bigBlind;
      bigBlindPlayer.chipCount -= this.bigBlind;
      this.pot += this.bigBlind;

      this.currentBet = this.bigBlind;
      this.currentPlayerIndex = (this.dealerPosition + 2) % playerArray.length;
    }
  }

  async handlePlayerAction(userId: string, action: PlayerAction, amount?: string): Promise<{ success: boolean; error?: string }> {
    const player = this.players.get(userId);
    if (!player) {
      return { success: false, error: 'Player not found' };
    }

    if (player.hasFolded) {
      return { success: false, error: 'Player has already folded' };
    }

    const currentPlayer = this.getCurrentPlayer();
    if (!currentPlayer || currentPlayer.id !== userId) {
      return { success: false, error: 'Not your turn' };
    }

    const actionAmount = amount ? parseFloat(amount) : 0;

    switch (action) {
      case 'fold':
        player.hasFolded = true;
        player.hasActed = true;
        break;

      case 'check':
        if (player.currentBet < this.currentBet) {
          return { success: false, error: 'Cannot check, must call or fold' };
        }
        player.hasActed = true;
        break;

      case 'call':
        const callAmount = this.currentBet - player.currentBet;
        if (player.chipCount < callAmount) {
          // All-in
          this.pot += player.chipCount;
          player.totalBet += player.chipCount;
          player.currentBet += player.chipCount;
          player.chipCount = 0;
          player.isAllIn = true;
        } else {
          this.pot += callAmount;
          player.totalBet += callAmount;
          player.currentBet += callAmount;
          player.chipCount -= callAmount;
        }
        player.hasActed = true;
        break;

      case 'raise':
        if (!actionAmount || actionAmount <= this.currentBet) {
          return { success: false, error: 'Invalid raise amount' };
        }
        
        const raiseAmount = actionAmount - player.currentBet;
        if (player.chipCount < raiseAmount) {
          return { success: false, error: 'Insufficient chips' };
        }

        this.pot += raiseAmount;
        player.totalBet += raiseAmount;
        player.currentBet += raiseAmount;
        player.chipCount -= raiseAmount;
        this.currentBet = actionAmount;
        
        // Reset other players' hasActed status
        for (const p of this.players.values()) {
          if (p.id !== userId && !p.hasFolded) {
            p.hasActed = false;
          }
        }
        player.hasActed = true;
        break;

      case 'all_in':
        const allInAmount = player.chipCount;
        this.pot += allInAmount;
        player.totalBet += allInAmount;
        player.currentBet += allInAmount;
        player.chipCount = 0;
        player.isAllIn = true;
        player.hasActed = true;
        
        if (player.currentBet > this.currentBet) {
          this.currentBet = player.currentBet;
          // Reset other players' hasActed status
          for (const p of this.players.values()) {
            if (p.id !== userId && !p.hasFolded) {
              p.hasActed = false;
            }
          }
        }
        break;
    }

    // Move to next player or next betting round
    await this.advanceGame();
    
    // Update database
    await this.updateGameInDatabase();

    return { success: true };
  }

  private async advanceGame(): Promise<void> {
    // Check if betting round is complete
    const activePlayers = Array.from(this.players.values()).filter(p => !p.hasFolded);
    const playersWhoCanAct = activePlayers.filter(p => !p.isAllIn);
    
    // If only one player left, they win
    if (activePlayers.length === 1) {
      await this.endHand(activePlayers[0].id);
      return;
    }

    // Check if all players have acted and bets are equal
    const allActed = playersWhoCanAct.every(p => p.hasActed);
    const betsEqual = playersWhoCanAct.every(p => p.currentBet === this.currentBet);

    if (allActed && betsEqual) {
      // Move to next betting round
      await this.nextBettingRound();
    } else {
      // Move to next player
      this.moveToNextPlayer();
    }
  }

  private async nextBettingRound(): Promise<void> {
    // Reset for next round
    for (const player of this.players.values()) {
      player.hasActed = false;
      player.currentBet = 0;
    }
    this.currentBet = 0;

    switch (this.gameState) {
      case 'preflop':
        // Deal flop (3 cards)
        this.deck.pop(); // Burn card
        for (let i = 0; i < 3; i++) {
          if (this.deck.length > 0) {
            this.communityCards.push(this.deck.pop()!);
          }
        }
        this.gameState = 'flop';
        break;

      case 'flop':
        // Deal turn (1 card)
        this.deck.pop(); // Burn card
        if (this.deck.length > 0) {
          this.communityCards.push(this.deck.pop()!);
        }
        this.gameState = 'turn';
        break;

      case 'turn':
        // Deal river (1 card)
        this.deck.pop(); // Burn card
        if (this.deck.length > 0) {
          this.communityCards.push(this.deck.pop()!);
        }
        this.gameState = 'river';
        break;

      case 'river':
        // Showdown
        await this.showdown();
        return;
    }

    // Set first active player to act
    this.currentPlayerIndex = this.dealerPosition;
    this.moveToNextPlayer();
  }

  private moveToNextPlayer(): void {
    const playerArray = Array.from(this.players.values()).sort((a, b) => a.position - b.position);
    const activePlayers = playerArray.filter(p => !p.hasFolded && !p.isAllIn);
    
    if (activePlayers.length === 0) return;

    do {
      this.currentPlayerIndex = (this.currentPlayerIndex + 1) % playerArray.length;
    } while (
      this.currentPlayerIndex < playerArray.length &&
      (playerArray[this.currentPlayerIndex].hasFolded || 
       playerArray[this.currentPlayerIndex].isAllIn ||
       playerArray[this.currentPlayerIndex].hasActed)
    );
  }

  private getCurrentPlayer(): PlayerState | null {
    const playerArray = Array.from(this.players.values()).sort((a, b) => a.position - b.position);
    return playerArray[this.currentPlayerIndex] || null;
  }

  private async showdown(): Promise<void> {
    const activePlayers = Array.from(this.players.values()).filter(p => !p.hasFolded);
    
    let bestHand = { strength: -1, description: '', playerId: '' };
    
    for (const player of activePlayers) {
      const allCards = [...player.holeCards, ...this.communityCards];
      const hand = this.evaluateHand(allCards);
      
      if (hand.strength > bestHand.strength) {
        bestHand = {
          ...hand,
          playerId: player.id
        };
      }
    }

    await this.endHand(bestHand.playerId, bestHand.description);
  }

  private async endHand(winnerId: string, winningHand?: string): Promise<void> {
    const winner = this.players.get(winnerId);
    if (winner) {
      // Calculate house fee (3%)
      const houseFee = this.pot * 0.03;
      const winnings = this.pot - houseFee;
      
      winner.chipCount += winnings;

      // Create transaction for winnings
      await this.storage.createTransaction({
        userId: winnerId,
        gameId: this.gameId,
        type: 'win',
        amount: winnings.toString(),
        description: `Won hand #${this.handNumber} with ${winningHand || 'best hand'}`
      });

      // Create transaction for house fee
      await this.storage.createTransaction({
        userId: winnerId,
        gameId: this.gameId,
        type: 'fee',
        amount: houseFee.toString(),
        description: `House fee for hand #${this.handNumber}`
      });

      // Update game in database
      await this.storage.finishGame(this.gameId, winnerId, winningHand || 'Best hand');
    }

    // Prepare for next hand
    this.handNumber++;
    this.dealerPosition = (this.dealerPosition + 1) % this.players.size;
    
    // Remove players with no chips
    for (const [playerId, player] of this.players.entries()) {
      if (player.chipCount <= 0) {
        this.players.delete(playerId);
      }
    }

    // Start new hand if enough players
    if (this.players.size >= 2) {
      setTimeout(() => this.startNewHand(), 5000); // 5 second delay
    } else {
      this.gameState = 'waiting';
    }
  }

  private async updateGameInDatabase(): Promise<void> {
    await this.storage.updateGameState(this.gameId, {
      communityCards: this.communityCards,
      pot: this.pot.toString(),
      gameState: this.gameState,
      handNumber: this.handNumber
    });
  }

  async getGameState(): Promise<GameStateData> {
    const currentPlayer = this.getCurrentPlayer();
    
    return {
      gameId: this.gameId,
      tableId: '', // Will be set by caller
      state: this.gameState,
      pot: this.pot,
      communityCards: this.communityCards,
      currentPlayer: currentPlayer?.id || null,
      players: Array.from(this.players.values()),
      dealerPosition: this.dealerPosition,
      smallBlindPosition: this.dealerPosition,
      bigBlindPosition: (this.dealerPosition + 1) % this.players.size,
      currentBet: this.currentBet,
      handNumber: this.handNumber
    };
  }
}
