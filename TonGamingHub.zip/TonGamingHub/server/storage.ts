import { 
  users, 
  pokerTables, 
  pokerGames, 
  gameParticipants, 
  transactions, 
  chatMessages,
  type User, 
  type InsertUser,
  type PokerTable,
  type InsertPokerTable,
  type PokerGame,
  type GameParticipant,
  type Transaction,
  type InsertTransaction,
  type ChatMessage,
  type InsertChatMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: string, newBalance: string): Promise<void>;
  updateUserWallet(userId: string, walletAddress: string): Promise<void>;

  // Table operations
  createTable(table: InsertPokerTable & { createdBy: string }): Promise<PokerTable>;
  getTable(id: string): Promise<PokerTable | undefined>;
  getActiveTables(): Promise<PokerTable[]>;
  updateTablePlayerCount(tableId: string, count: number): Promise<void>;

  // Game operations
  createGame(gameData: Partial<PokerGame> & { tableId: string }): Promise<PokerGame>;
  getGame(id: string): Promise<PokerGame | undefined>;
  updateGameState(gameId: string, state: any): Promise<void>;
  finishGame(gameId: string, winnerId: string, winningHand: string): Promise<void>;

  // Participant operations
  addParticipant(participantData: Omit<GameParticipant, 'id' | 'joinedAt'>): Promise<GameParticipant>;
  getGameParticipants(gameId: string): Promise<GameParticipant[]>;
  updateParticipant(participantId: string, updates: Partial<GameParticipant>): Promise<void>;
  removeParticipant(participantId: string): Promise<void>;

  // Transaction operations
  createTransaction(transaction: InsertTransaction & { userId: string; gameId?: string }): Promise<Transaction>;
  getUserTransactions(userId: string): Promise<Transaction[]>;
  updateTransactionStatus(transactionId: string, status: string, tonTxHash?: string): Promise<void>;

  // Chat operations
  addChatMessage(message: InsertChatMessage & { gameId: string; userId: string }): Promise<ChatMessage>;
  getGameChatMessages(gameId: string, limit?: number): Promise<ChatMessage[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserBalance(userId: string, newBalance: string): Promise<void> {
    await db
      .update(users)
      .set({ 
        balance: newBalance,
        lastActiveAt: new Date()
      })
      .where(eq(users.id, userId));
  }

  async updateUserWallet(userId: string, walletAddress: string): Promise<void> {
    await db
      .update(users)
      .set({ tonWalletAddress: walletAddress })
      .where(eq(users.id, userId));
  }

  async createTable(tableData: InsertPokerTable & { createdBy: string }): Promise<PokerTable> {
    const [table] = await db
      .insert(pokerTables)
      .values(tableData)
      .returning();
    return table;
  }

  async getTable(id: string): Promise<PokerTable | undefined> {
    const [table] = await db.select().from(pokerTables).where(eq(pokerTables.id, id));
    return table || undefined;
  }

  async getActiveTables(): Promise<PokerTable[]> {
    return await db
      .select()
      .from(pokerTables)
      .where(eq(pokerTables.isActive, true))
      .orderBy(asc(pokerTables.createdAt));
  }

  async updateTablePlayerCount(tableId: string, count: number): Promise<void> {
    await db
      .update(pokerTables)
      .set({ currentPlayers: count })
      .where(eq(pokerTables.id, tableId));
  }

  async createGame(gameData: Partial<PokerGame> & { tableId: string }): Promise<PokerGame> {
    const [game] = await db
      .insert(pokerGames)
      .values(gameData)
      .returning();
    return game;
  }

  async getGame(id: string): Promise<PokerGame | undefined> {
    const [game] = await db.select().from(pokerGames).where(eq(pokerGames.id, id));
    return game || undefined;
  }

  async updateGameState(gameId: string, updates: Partial<PokerGame>): Promise<void> {
    await db
      .update(pokerGames)
      .set(updates)
      .where(eq(pokerGames.id, gameId));
  }

  async finishGame(gameId: string, winnerId: string, winningHand: string): Promise<void> {
    await db
      .update(pokerGames)
      .set({
        gameState: 'finished',
        winnerId,
        winningHand,
        finishedAt: new Date()
      })
      .where(eq(pokerGames.id, gameId));
  }

  async addParticipant(participantData: Omit<GameParticipant, 'id' | 'joinedAt'>): Promise<GameParticipant> {
    const [participant] = await db
      .insert(gameParticipants)
      .values(participantData)
      .returning();
    return participant;
  }

  async getGameParticipants(gameId: string): Promise<GameParticipant[]> {
    return await db
      .select()
      .from(gameParticipants)
      .where(and(
        eq(gameParticipants.gameId, gameId),
        eq(gameParticipants.leftAt, null)
      ))
      .orderBy(asc(gameParticipants.position));
  }

  async updateParticipant(participantId: string, updates: Partial<GameParticipant>): Promise<void> {
    await db
      .update(gameParticipants)
      .set(updates)
      .where(eq(gameParticipants.id, participantId));
  }

  async removeParticipant(participantId: string): Promise<void> {
    await db
      .update(gameParticipants)
      .set({ leftAt: new Date() })
      .where(eq(gameParticipants.id, participantId));
  }

  async createTransaction(transaction: InsertTransaction & { userId: string; gameId?: string }): Promise<Transaction> {
    const [tx] = await db
      .insert(transactions)
      .values(transaction)
      .returning();
    return tx;
  }

  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async updateTransactionStatus(transactionId: string, status: string, tonTxHash?: string): Promise<void> {
    const updates: any = { status };
    if (tonTxHash) updates.tonTxHash = tonTxHash;
    if (status === 'confirmed') updates.confirmedAt = new Date();

    await db
      .update(transactions)
      .set(updates)
      .where(eq(transactions.id, transactionId));
  }

  async addChatMessage(message: InsertChatMessage & { gameId: string; userId: string }): Promise<ChatMessage> {
    const [chatMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return chatMessage;
  }

  async getGameChatMessages(gameId: string, limit: number = 50): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.gameId, gameId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
