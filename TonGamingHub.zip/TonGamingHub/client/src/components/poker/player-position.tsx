import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface PlayerPositionProps {
  player: {
    id: string;
    name: string;
    position: number;
    chipCount: number;
    holeCards: { rank: string; suit: string }[];
    isCurrentPlayer?: boolean;
    status: 'active' | 'thinking' | 'folded' | 'all_in' | 'away';
  };
  isCurrentUser: boolean;
  dealerPosition: number;
}

export function PlayerPosition({ player, isCurrentUser, dealerPosition }: PlayerPositionProps) {
  const getPositionStyles = (position: number): string => {
    const positions = [
      "bottom-4 left-1/2 transform -translate-x-1/2", // Bottom (seat 0)
      "bottom-8 left-8", // Bottom Left (seat 1)
      "left-4 top-1/2 transform -translate-y-1/2", // Left (seat 2)
      "top-8 left-8", // Top Left (seat 3)
      "top-4 left-1/2 transform -translate-x-1/2", // Top (seat 4)
      "top-8 right-8", // Top Right (seat 5)
      "right-4 top-1/2 transform -translate-y-1/2", // Right (seat 6)
      "bottom-8 right-8" // Bottom Right (seat 7)
    ];
    return positions[position] || positions[0];
  };

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'thinking': return 'text-yellow-400';
      case 'folded': return 'text-red-400';
      case 'all_in': return 'text-orange-400';
      case 'away': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusText = (status: string): string => {
    switch (status) {
      case 'active': return 'In Hand';
      case 'thinking': return 'Thinking...';
      case 'folded': return 'Folded';
      case 'all_in': return 'All In';
      case 'away': return 'Away';
      default: return 'Waiting';
    }
  };

  const getAvatarUrl = (playerId: string): string => {
    // Generate consistent avatar based on player ID
    const avatars = [
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop&crop=face",
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop&crop=face",
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop&crop=face",
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop&crop=face"
    ];
    return avatars[playerId.length % avatars.length];
  };

  return (
    <div 
      className={`absolute ${getPositionStyles(player.position)} ${
        player.isCurrentPlayer ? 'player-active' : ''
      } rounded-lg p-4 transition-all duration-300`}
    >
      <div className="text-center">
        {/* Player Cards */}
        <div className="flex space-x-2 mb-3 justify-center">
          {isCurrentUser && player.holeCards.length > 0 ? (
            // Show actual cards for current user
            player.holeCards.map((card, index) => (
              <div key={index} className="card w-12 h-18 flex items-center justify-center text-black font-bold text-sm rounded shadow-sm">
                {card.rank}{card.suit}
              </div>
            ))
          ) : (
            // Show card backs for other players
            player.status !== 'folded' && (
              <>
                <div className="card-back w-12 h-18 rounded shadow-sm"></div>
                <div className="card-back w-12 h-18 rounded shadow-sm"></div>
              </>
            )
          )}
        </div>
        
        {/* Player Avatar (only for non-current users) */}
        {!isCurrentUser && (
          <Avatar className="w-12 h-12 mx-auto mb-2 border-2 border-gray-600">
            <AvatarImage src={getAvatarUrl(player.id)} alt={player.name} />
            <AvatarFallback className="bg-gray-700 text-white">
              {player.name.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
        )}
        
        {/* Player Info */}
        <Card className="bg-black/70 border-gray-600 backdrop-blur-sm">
          <div className="px-3 py-2">
            <div className={`font-semibold text-sm ${isCurrentUser ? 'text-poker-gold' : 'text-white'}`}>
              {isCurrentUser ? 'You' : player.name}
            </div>
            <div className="text-white font-mono text-xs">
              {player.chipCount.toLocaleString(undefined, { 
                minimumFractionDigits: 2, 
                maximumFractionDigits: 2 
              })} TON
            </div>
            <Badge 
              variant="outline" 
              className={`text-xs ${getStatusColor(player.status)} border-current`}
            >
              {getStatusText(player.status)}
            </Badge>
          </div>
        </Card>

        {/* Dealer Button */}
        {player.position === dealerPosition && (
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-poker-gold rounded-full flex items-center justify-center text-black font-bold text-xs shadow-lg">
            D
          </div>
        )}

        {/* Current Player Indicator */}
        {player.isCurrentPlayer && (
          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
            <div className="w-2 h-2 bg-poker-gold rounded-full animate-pulse-gold"></div>
          </div>
        )}
      </div>
    </div>
  );
}
