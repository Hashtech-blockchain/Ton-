import { Button } from "@/components/ui/button";
import { Phone, Hand, X, TrendingUp, Zap } from "lucide-react";

interface ActionButtonsProps {
  onAction: (action: string) => void;
  currentBet: number;
  playerChips: number;
  canCheck: boolean;
}

export function ActionButtons({ onAction, currentBet, playerChips, canCheck }: ActionButtonsProps) {
  return (
    <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-4 z-10">
      {/* Fold Button */}
      <Button 
        onClick={() => onAction('fold')}
        className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 font-semibold transition-all duration-200 hover:scale-105"
        size="lg"
      >
        <X className="w-4 h-4 mr-2" />
        Fold
      </Button>

      {/* Check/Call Button */}
      {canCheck ? (
        <Button 
          onClick={() => onAction('check')}
          className="bg-yellow-600 hover:bg-yellow-700 text-white px-6 py-3 font-semibold transition-all duration-200 hover:scale-105"
          size="lg"
        >
          <Hand className="w-4 h-4 mr-2" />
          Check
        </Button>
      ) : (
        <Button 
          onClick={() => onAction('call')}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 font-semibold transition-all duration-200 hover:scale-105"
          size="lg"
        >
          <Phone className="w-4 h-4 mr-2" />
          Call {currentBet.toFixed(2)} TON
        </Button>
      )}

      {/* Raise Button */}
      <Button 
        onClick={() => onAction('raise')}
        className="bg-poker-gold hover:bg-poker-orange text-black px-6 py-3 font-semibold transition-all duration-200 hover:scale-105"
        size="lg"
      >
        <TrendingUp className="w-4 h-4 mr-2" />
        Raise
      </Button>

      {/* All-In Button */}
      <Button 
        onClick={() => onAction('all_in')}
        className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 font-semibold transition-all duration-200 hover:scale-105"
        size="lg"
      >
        <Zap className="w-4 h-4 mr-2" />
        All In ({playerChips.toFixed(2)} TON)
      </Button>
    </div>
  );
}
