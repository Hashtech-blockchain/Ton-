import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Users, Plus, TrendingUp, Clock, Coins } from "lucide-react";

interface TournamentLobbyProps {
  isOpen: boolean;
  onClose: () => void;
  tables: any[];
  onJoinTable: (tableId: string, chipCount: number) => void;
  currentUser: { id: string; name: string };
}

export function TournamentLobby({ 
  isOpen, 
  onClose, 
  tables, 
  onJoinTable, 
  currentUser 
}: TournamentLobbyProps) {
  const [activeTab, setActiveTab] = useState<'browse' | 'create'>('browse');
  const [tableName, setTableName] = useState("");
  const [smallBlind, setSmallBlind] = useState("0.1");
  const [maxPlayers, setMaxPlayers] = useState("8");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Create table mutation
  const createTableMutation = useMutation({
    mutationFn: async (tableData: any) => {
      const response = await apiRequest('POST', '/api/tables', {
        ...tableData,
        createdBy: currentUser.id
      });
      return response.json();
    },
    onSuccess: (newTable) => {
      toast({
        title: "Table Created",
        description: `Successfully created table "${newTable.name}"`
      });
      setTableName("");
      setSmallBlind("0.1");
      setMaxPlayers("8");
      setActiveTab('browse');
      queryClient.invalidateQueries({ queryKey: ['/api/tables'] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Create Table",
        description: error.message || "Could not create the table",
        variant: "destructive"
      });
    }
  });

  const handleCreateTable = () => {
    if (!tableName.trim()) {
      toast({
        title: "Invalid Table Name",
        description: "Please enter a table name",
        variant: "destructive"
      });
      return;
    }

    const blindValue = parseFloat(smallBlind);
    if (isNaN(blindValue) || blindValue <= 0) {
      toast({
        title: "Invalid Blinds",
        description: "Please enter valid blind amounts",
        variant: "destructive"
      });
      return;
    }

    createTableMutation.mutate({
      name: tableName.trim(),
      smallBlind: blindValue.toString(),
      bigBlind: (blindValue * 2).toString(),
      maxPlayers: parseInt(maxPlayers)
    });
  };

  const getTableStatusColor = (currentPlayers: number, maxPlayers: number): string => {
    const percentage = (currentPlayers / maxPlayers) * 100;
    if (percentage >= 90) return "text-red-400";
    if (percentage >= 70) return "text-yellow-400";
    return "text-green-400";
  };

  const getAveragePot = (smallBlind: string): number => {
    const blind = parseFloat(smallBlind);
    return blind * 45; // Approximate average pot multiplier
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-poker-gold flex items-center">
            <Users className="w-6 h-6 mr-2" />
            Tournament Lobby
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Tab Navigation */}
          <div className="flex space-x-1 bg-gray-800 rounded-lg p-1">
            <button
              onClick={() => setActiveTab('browse')}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors flex items-center justify-center ${
                activeTab === 'browse' 
                  ? 'bg-poker-gold text-black' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Users className="w-4 h-4 mr-2" />
              Browse Tables
            </button>
            <button
              onClick={() => setActiveTab('create')}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors flex items-center justify-center ${
                activeTab === 'create' 
                  ? 'bg-poker-gold text-black' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Table
            </button>
          </div>

          {/* Browse Tables Tab */}
          {activeTab === 'browse' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">Available Tables</h3>
                <Badge variant="outline" className="text-poker-gold border-poker-gold">
                  {tables.length} Tables Active
                </Badge>
              </div>

              {tables.length === 0 ? (
                <Card className="bg-gray-800 border-gray-600">
                  <CardContent className="p-8 text-center">
                    <Clock className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-300 mb-2">No Active Tables</h3>
                    <p className="text-gray-500 mb-4">Be the first to create a poker table!</p>
                    <Button 
                      onClick={() => setActiveTab('create')}
                      className="bg-poker-gold text-black hover:bg-poker-orange"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create New Table
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {tables.map((table: any) => {
                    const avgPot = getAveragePot(table.smallBlind);
                    const isFull = table.currentPlayers >= table.maxPlayers;
                    
                    return (
                      <Card 
                        key={table.id} 
                        className="bg-gray-800 border-gray-600 hover:border-poker-gold transition-colors cursor-pointer"
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className="text-white text-lg">{table.name}</CardTitle>
                              <div className="flex items-center space-x-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  Texas Hold'em
                                </Badge>
                                {table.isActive && (
                                  <Badge className="bg-green-600 text-white text-xs">
                                    Active
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-green-400 font-mono text-lg">
                                ~{avgPot.toFixed(0)} TON
                              </div>
                              <div className="text-gray-400 text-xs">Avg. Pot</div>
                            </div>
                          </div>
                        </CardHeader>
                        
                        <CardContent className="space-y-3">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-400">Blinds:</span>
                              <div className="text-poker-gold font-mono">
                                {table.smallBlind}/{table.bigBlind} TON
                              </div>
                            </div>
                            <div>
                              <span className="text-gray-400">Players:</span>
                              <div className={`font-semibold ${getTableStatusColor(table.currentPlayers, table.maxPlayers)}`}>
                                {table.currentPlayers}/{table.maxPlayers}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-xs text-gray-400">
                            <div className="flex items-center space-x-4">
                              <span>Buy-in: {(parseFloat(table.bigBlind) * 50).toFixed(1)} TON</span>
                              <span>Fee: 3%</span>
                            </div>
                            <span>Created {new Date(table.createdAt).toLocaleDateString()}</span>
                          </div>

                          <Button 
                            onClick={() => onJoinTable(table.id, parseFloat(table.bigBlind) * 50)}
                            disabled={isFull}
                            className="w-full bg-poker-gold text-black hover:bg-poker-orange disabled:bg-gray-600 disabled:text-gray-400"
                          >
                            {isFull ? "Table Full" : `Join Table (${(parseFloat(table.bigBlind) * 50).toFixed(1)} TON)`}
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Create Table Tab */}
          {activeTab === 'create' && (
            <div className="space-y-6">
              <h3 className="text-lg font-semibold text-white">Create New Table</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Table Configuration */}
                <Card className="bg-gray-800 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-poker-gold flex items-center">
                      <Plus className="w-5 h-5 mr-2" />
                      Table Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="table-name" className="text-gray-300">
                        Table Name
                      </Label>
                      <Input
                        id="table-name"
                        value={tableName}
                        onChange={(e) => setTableName(e.target.value)}
                        placeholder="My Poker Table"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="small-blind" className="text-gray-300">
                        Small Blind (TON)
                      </Label>
                      <Select value={smallBlind} onValueChange={setSmallBlind}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="0.1">0.1 TON</SelectItem>
                          <SelectItem value="0.5">0.5 TON</SelectItem>
                          <SelectItem value="1">1 TON</SelectItem>
                          <SelectItem value="5">5 TON</SelectItem>
                          <SelectItem value="10">10 TON</SelectItem>
                        </SelectContent>
                      </Select>
                      <div className="text-xs text-gray-400 mt-1">
                        Big Blind: {(parseFloat(smallBlind) * 2).toFixed(1)} TON
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="max-players" className="text-gray-300">
                        Max Players
                      </Label>
                      <Select value={maxPlayers} onValueChange={setMaxPlayers}>
                        <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-gray-700 border-gray-600">
                          <SelectItem value="6">6 Players</SelectItem>
                          <SelectItem value="8">8 Players</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>

                {/* Table Preview */}
                <Card className="bg-gray-800 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-poker-gold flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2" />
                      Table Preview
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Game Type:</span>
                        <span className="text-white">Texas Hold'em</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Blinds:</span>
                        <span className="text-white font-mono">
                          {smallBlind}/{(parseFloat(smallBlind) * 2).toFixed(1)} TON
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Buy-in Range:</span>
                        <span className="text-white font-mono">
                          {(parseFloat(smallBlind) * 20).toFixed(1)} - {(parseFloat(smallBlind) * 100).toFixed(1)} TON
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">House Fee:</span>
                        <span className="text-poker-orange">3%</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Est. Avg Pot:</span>
                        <span className="text-green-400 font-mono">
                          ~{getAveragePot(smallBlind).toFixed(0)} TON
                        </span>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-700">
                      <div className="flex items-center space-x-2 text-xs text-gray-400 mb-4">
                        <Coins className="w-4 h-4" />
                        <span>All transactions secured by TON Blockchain</span>
                      </div>
                      
                      <Button 
                        onClick={handleCreateTable}
                        disabled={createTableMutation.isPending || !tableName.trim()}
                        className="w-full bg-poker-gold hover:bg-poker-orange text-black font-semibold"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        {createTableMutation.isPending ? "Creating..." : "Create Table"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
