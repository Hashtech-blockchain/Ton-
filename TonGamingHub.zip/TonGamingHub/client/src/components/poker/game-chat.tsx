import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Send, Users, Clock } from "lucide-react";

interface GameChatProps {
  gameId: string;
  currentUser: { id: string; name: string };
  gameState: any;
}

export function GameChat({ gameId, currentUser, gameState }: GameChatProps) {
  const [message, setMessage] = useState("");
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  // Fetch chat messages
  const { data: messages = [], isLoading } = useQuery({
    queryKey: ['/api/games', gameId, 'chat'],
    refetchInterval: 1000 // Refetch every second for real-time updates
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await apiRequest('POST', `/api/games/${gameId}/chat`, {
        message: messageText,
        type: 'user',
        userId: currentUser.id
      });
      return response.json();
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ['/api/games', gameId, 'chat'] });
    }
  });

  const handleSendMessage = () => {
    if (message.trim()) {
      sendMessageMutation.mutate(message.trim());
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  // Mock game info when gameState is not available
  const mockGameInfo = {
    gameType: "Texas Hold'em",
    blinds: "0.1/0.2 TON",
    players: "6/8",
    houseFee: "3%",
    handNumber: "#2,847"
  };

  const currentGameInfo = gameState || mockGameInfo;

  // Mock recent hands
  const mockHandHistory = [
    {
      id: "2846",
      winner: "PokerAce",
      pot: 145.50,
      timeAgo: "2 min ago"
    },
    {
      id: "2845",
      winner: "You",
      pot: 89.20,
      timeAgo: "5 min ago",
      isWin: true
    }
  ];

  // Mock messages when real data is not available
  const mockMessages = [
    {
      id: "1",
      userId: "player2",
      message: "Good luck everyone! 🎰",
      type: "user",
      createdAt: new Date(Date.now() - 300000).toISOString(),
      user: { username: "CryptoKing" }
    },
    {
      id: "2",
      userId: "player3",
      message: "Nice flop!",
      type: "user",
      createdAt: new Date(Date.now() - 180000).toISOString(),
      user: { username: "PokerAce" }
    },
    {
      id: "3",
      userId: "system",
      message: "ChipLeader went all in for 2,100 TON",
      type: "system",
      createdAt: new Date(Date.now() - 120000).toISOString(),
      user: { username: "System" }
    },
    {
      id: "4",
      userId: "player4",
      message: "Too rich for my blood 😅",
      type: "user",
      createdAt: new Date(Date.now() - 60000).toISOString(),
      user: { username: "BluffMaster" }
    }
  ];

  const displayMessages = messages.length > 0 ? messages : mockMessages;

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col h-full">
      {/* Game Info Panel */}
      <Card className="m-4 mb-0 bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-poker-gold flex items-center">
            <Users className="w-5 h-5 mr-2" />
            Game Info
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-400">Game Type:</span>
            <span className="text-white">{currentGameInfo.gameType || "Texas Hold'em"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Blinds:</span>
            <span className="text-white font-mono">{currentGameInfo.blinds || "0.1/0.2 TON"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Players:</span>
            <span className="text-white">{currentGameInfo.players || "6/8"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">House Fee:</span>
            <span className="text-poker-orange">{currentGameInfo.houseFee || "3%"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Hand #:</span>
            <span className="text-white font-mono">{currentGameInfo.handNumber || "#2,847"}</span>
          </div>
        </CardContent>
      </Card>

      {/* Chat Section */}
      <Card className="flex-1 m-4 my-2 bg-gray-800 border-gray-700 flex flex-col">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-poker-gold">Chat</CardTitle>
        </CardHeader>
        
        <CardContent className="flex-1 flex flex-col p-0">
          {/* Chat Messages */}
          <ScrollArea className="flex-1 px-4" ref={scrollAreaRef}>
            <div className="space-y-3 py-2">
              {isLoading ? (
                <div className="text-center text-gray-400">Loading messages...</div>
              ) : (
                displayMessages.map((msg: any) => (
                  <div key={msg.id} className="text-sm animate-fade-in">
                    <div className="flex items-start space-x-2">
                      <span className="text-xs text-gray-500 mt-1">
                        {formatTime(msg.createdAt)}
                      </span>
                      <div className="flex-1">
                        {msg.type === 'system' ? (
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline" className="text-green-400 border-green-400">
                              System
                            </Badge>
                            <span className="text-gray-400">{msg.message}</span>
                          </div>
                        ) : (
                          <div>
                            <span className={`font-semibold ${
                              msg.userId === currentUser.id ? 'text-poker-gold' : 'text-blue-400'
                            }`}>
                              {msg.userId === currentUser.id ? 'You' : (msg.user?.username || 'Player')}:
                            </span>
                            <span className="text-gray-300 ml-2">{msg.message}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
          
          {/* Chat Input */}
          <div className="p-4 border-t border-gray-700">
            <div className="flex space-x-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type a message..."
                className="flex-1 bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-poker-gold"
                disabled={sendMessageMutation.isPending}
              />
              <Button 
                onClick={handleSendMessage}
                disabled={!message.trim() || sendMessageMutation.isPending}
                className="bg-poker-gold hover:bg-poker-orange text-black"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hand History */}
      <Card className="m-4 mt-0 bg-gray-800 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-poker-gold flex items-center">
            <Clock className="w-5 h-5 mr-2" />
            Recent Hands
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-xs">
          {mockHandHistory.map((hand) => (
            <Card key={hand.id} className="bg-gray-700 border-gray-600">
              <CardContent className="p-2">
                <div className="flex justify-between text-gray-400 mb-1">
                  <span>Hand #{hand.id}</span>
                  <span>{hand.timeAgo}</span>
                </div>
                <div className="text-white">
                  Winner: <span className={hand.isWin ? 'text-poker-gold' : 'text-blue-400'}>
                    {hand.winner}
                  </span>
                </div>
                <div className={hand.isWin ? 'text-green-400' : 'text-gray-400'}>
                  Pot: {hand.pot.toFixed(2)} TON {hand.isWin && '(+)'}
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
