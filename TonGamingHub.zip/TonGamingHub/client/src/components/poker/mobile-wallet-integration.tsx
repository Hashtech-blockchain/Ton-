import React, { useState } from 'react';
import { useTonWallet, useTonConnectUI, TonConnectButton } from '@tonconnect/ui-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Wallet, Send, ArrowDownToLine, ExternalLink, Copy, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface MobileWalletIntegrationProps {
  userBalance: number;
  onBalanceUpdate: (amount: number) => void;
}

export const MobileWalletIntegration: React.FC<MobileWalletIntegrationProps> = ({ 
  userBalance, 
  onBalanceUpdate 
}) => {
  const wallet = useTonWallet();
  const [tonConnectUI] = useTonConnectUI();
  const { toast } = useToast();

  const isConnected = !!wallet;
  const userAddress = wallet?.account?.address;
  const feeWallet = 'UQBGvXxhIN2vZXjOM4pzwO6CQF-Ak3AqGqpCqcsAUB8cxw76';
  const earningsAddress = '9f22bccb015b9062e7455ec80bbe70814b559f2ad5343f210cf13a9378da3bd7';

  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');

  const handleDeposit = async () => {
    toast({
      title: "Deposito simulato",
      description: `Deposito di ${depositAmount} TON simulato con successo.`,
    });
    onBalanceUpdate(userBalance + Number(depositAmount));
    setDepositAmount('');
  };

  const handleWithdraw = async () => {
    toast({
      title: "Prelievo simulato", 
      description: `Prelievo di ${withdrawAmount} TON simulato con successo.`,
    });
    onBalanceUpdate(userBalance - Number(withdrawAmount));
    setWithdrawAmount('');
    setWithdrawAddress('');
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copiato",
        description: "Indirizzo copiato negli appunti.",
      });
    } catch (error) {
      toast({
        title: "Errore",
        description: "Impossibile copiare l'indirizzo.",
        variant: "destructive",
      });
    }
  };

  if (!isConnected) {
    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button 
            variant="outline" 
            className="bg-blue-600 hover:bg-blue-700 text-white border-blue-600"
          >
            <Wallet className="w-4 h-4 mr-2" />
            Connetti Wallet Web3
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">Connetti Wallet TON Mobile</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-center text-sm text-muted-foreground">
              <p>Connetti il tuo wallet TON mobile per:</p>
              <ul className="mt-2 space-y-1 text-left">
                <li>• Depositare TON per giocare</li>
                <li>• Prelevare le tue vincite</li>
                <li>• Giocare con criptovalute reali</li>
                <li>• Transazioni sicure e trasparenti</li>
              </ul>
            </div>
            
            <div className="flex justify-center">
              <Button
                onClick={() => tonConnectUI.openModal()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Wallet className="w-4 h-4 mr-2" />
                Apri TonConnect
              </Button>
            </div>

            <div className="text-xs text-muted-foreground space-y-1">
              <p><strong>Wallet supportati:</strong></p>
              <p>• TonKeeper • Tonhub • OpenMask</p>
              <p>• Tutte le app wallet compatibili TonConnect</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="bg-green-600 hover:bg-green-700 text-white border-green-600"
        >
          <CheckCircle className="w-4 h-4 mr-2" />
          Wallet TON Connesso
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Gestione Wallet TON</DialogTitle>
        </DialogHeader>

        {/* Wallet Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between text-base">
              <span className="flex items-center gap-2">
                <Wallet className="w-4 h-4" />
                {wallet?.device?.appName || 'Wallet TON'}
              </span>
              <Badge className="bg-green-100 text-green-800">Connesso</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-xs">Indirizzo Wallet</Label>
              <div className="flex items-center gap-2">
                <Input 
                  value={userAddress || ''} 
                  readOnly 
                  className="text-xs font-mono"
                />
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => copyToClipboard(userAddress || '')}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <Label className="text-xs">Saldo Wallet</Label>
                <p className="font-semibold">{walletBalance || '0'} TON</p>
              </div>
              <div>
                <Label className="text-xs">Saldo Gioco</Label>
                <p className="font-semibold">{userBalance.toFixed(2)} TON</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <ArrowDownToLine className="w-4 h-4" />
                Deposita TON
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Importo TON</Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  min="0.01"
                  step="0.01"
                />
              </div>
              
              <Button 
                onClick={handleDeposit} 
                disabled={!depositAmount}
                className="w-full"
              >
                Deposita {depositAmount || '0'} TON
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Send className="w-4 h-4" />
                Preleva TON
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Importo TON</Label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  min="0.01"
                  step="0.01"
                  max={userBalance}
                />
              </div>
              
              <Button 
                onClick={handleWithdraw} 
                disabled={!withdrawAmount}
                className="w-full"
              >
                Preleva {withdrawAmount || '0'} TON
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* System Info */}
        <Card>
          <CardContent className="pt-4">
            <div className="text-xs space-y-1">
              <p><strong>Wallet Commissioni:</strong> {feeWallet}</p>
              <p><strong>Wallet Vincite:</strong> {earningsAddress}</p>
              <div className="flex gap-2 pt-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => tonConnectUI.disconnect()}
                  className="text-xs"
                >
                  Disconnetti Wallet
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => window.open(`https://tonviewer.com/${userAddress}`, '_blank')}
                  className="text-xs"
                >
                  <ExternalLink className="w-3 h-3 mr-1" />
                  Vedi su Explorer
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
};

export default MobileWalletIntegration;