import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Copy, Plus, Minus, Shield, Wallet, ExternalLink } from "lucide-react";

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
  balance: string;
  isWalletConnected: boolean;
  onConnect: () => void;
  onDisconnect: () => void;
}

export function WalletModal({ 
  isOpen, 
  onClose, 
  user, 
  balance, 
  isWalletConnected, 
  onConnect, 
  onDisconnect 
}: WalletModalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'deposit' | 'withdraw'>('overview');
  const [depositAmount, setDepositAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawAddress, setWithdrawAddress] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const HOUSE_WALLET = "UQBGvXxhIN2vZXjOM4pzwO6CQF-Ak3AqGqpCqcsAUB8cxw76";

  // Deposit mutation
  const depositMutation = useMutation({
    mutationFn: async (amount: string) => {
      const response = await apiRequest('POST', '/api/transactions', {
        type: 'deposit',
        amount,
        description: `Deposit ${amount} TON`,
        userId: user?.id
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Deposit Initiated",
        description: "Your deposit is being processed. It may take a few minutes to confirm."
      });
      setDepositAmount("");
      setActiveTab('overview');
      queryClient.invalidateQueries({ queryKey: ['/api/user', user?.id] });
    },
    onError: (error: any) => {
      toast({
        title: "Deposit Failed",
        description: error.message || "Failed to process deposit",
        variant: "destructive"
      });
    }
  });

  // Withdraw mutation
  const withdrawMutation = useMutation({
    mutationFn: async ({ amount, address }: { amount: string; address: string }) => {
      const response = await apiRequest('POST', '/api/transactions', {
        type: 'withdrawal',
        amount,
        description: `Withdraw ${amount} TON to ${address}`,
        userId: user?.id
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal Initiated",
        description: "Your withdrawal is being processed. It may take a few minutes to complete."
      });
      setWithdrawAmount("");
      setWithdrawAddress("");
      setActiveTab('overview');
      queryClient.invalidateQueries({ queryKey: ['/api/user', user?.id] });
    },
    onError: (error: any) => {
      toast({
        title: "Withdrawal Failed",
        description: error.message || "Failed to process withdrawal",
        variant: "destructive"
      });
    }
  });

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Address copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Could not copy to clipboard",
        variant: "destructive"
      });
    }
  };

  const handleDeposit = () => {
    if (!depositAmount || parseFloat(depositAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid deposit amount",
        variant: "destructive"
      });
      return;
    }
    depositMutation.mutate(depositAmount);
  };

  const handleWithdraw = () => {
    if (!withdrawAmount || parseFloat(withdrawAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid withdrawal amount",
        variant: "destructive"
      });
      return;
    }
    
    if (!withdrawAddress) {
      toast({
        title: "Missing Address",
        description: "Please enter a withdrawal address",
        variant: "destructive"
      });
      return;
    }

    const userBalance = parseFloat(user?.balance || "0");
    const requestedAmount = parseFloat(withdrawAmount);
    
    if (requestedAmount > userBalance) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough TON to withdraw",
        variant: "destructive"
      });
      return;
    }

    withdrawMutation.mutate({ amount: withdrawAmount, address: withdrawAddress });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-poker-gold flex items-center">
            <Wallet className="w-6 h-6 mr-2" />
            TON Wallet
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Wallet Connection Status */}
          <Card className="bg-gray-800 border-gray-600">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">Wallet Status</span>
                <Badge variant={isWalletConnected ? "default" : "secondary"}>
                  {isWalletConnected ? "Connected" : "Disconnected"}
                </Badge>
              </div>
              {!isWalletConnected && (
                <Button 
                  onClick={onConnect}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Connect TON Wallet
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Tab Navigation */}
          <div className="flex space-x-1 bg-gray-800 rounded-lg p-1">
            <button
              onClick={() => setActiveTab('overview')}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'overview' 
                  ? 'bg-poker-gold text-black' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('deposit')}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'deposit' 
                  ? 'bg-poker-gold text-black' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Deposit
            </button>
            <button
              onClick={() => setActiveTab('withdraw')}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                activeTab === 'withdraw' 
                  ? 'bg-poker-gold text-black' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Withdraw
            </button>
          </div>

          {/* Tab Content */}
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4">
                  <div className="text-sm text-gray-400 mb-1">Current Balance</div>
                  <div className="text-2xl font-bold text-poker-gold font-mono">
                    {user?.balance || "0.00"} TON
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4">
                  <div className="text-sm text-gray-400 mb-2">Deposit Address</div>
                  <div className="bg-black rounded p-2 text-xs font-mono text-gray-300 break-all mb-2">
                    {HOUSE_WALLET}
                  </div>
                  <Button 
                    onClick={() => copyToClipboard(HOUSE_WALLET)}
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Address
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'deposit' && (
            <div className="space-y-4">
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 space-y-4">
                  <div>
                    <Label htmlFor="deposit-amount" className="text-gray-300">
                      Deposit Amount (TON)
                    </Label>
                    <Input
                      id="deposit-amount"
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(e.target.value)}
                      placeholder="0.00"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  
                  <div className="text-xs text-gray-400 space-y-1">
                    <div>• Send TON to: <span className="font-mono">{HOUSE_WALLET}</span></div>
                    <div>• Minimum deposit: 0.01 TON</div>
                    <div>• Deposits are usually confirmed within 2-5 minutes</div>
                  </div>
                  
                  <Button 
                    onClick={handleDeposit}
                    disabled={depositMutation.isPending || !depositAmount}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    {depositMutation.isPending ? "Processing..." : "Confirm Deposit"}
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'withdraw' && (
            <div className="space-y-4">
              <Card className="bg-gray-800 border-gray-600">
                <CardContent className="p-4 space-y-4">
                  <div>
                    <Label htmlFor="withdraw-address" className="text-gray-300">
                      Withdrawal Address
                    </Label>
                    <Input
                      id="withdraw-address"
                      value={withdrawAddress}
                      onChange={(e) => setWithdrawAddress(e.target.value)}
                      placeholder="UQ..."
                      className="bg-gray-700 border-gray-600 text-white font-mono text-sm"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="withdraw-amount" className="text-gray-300">
                      Withdrawal Amount (TON)
                    </Label>
                    <Input
                      id="withdraw-amount"
                      type="number"
                      step="0.01"
                      min="0.01"
                      max={user?.balance || "0"}
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      placeholder="0.00"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                    <div className="text-xs text-gray-400 mt-1">
                      Available: {user?.balance || "0.00"} TON
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-400 space-y-1">
                    <div>• Minimum withdrawal: 0.01 TON</div>
                    <div>• Withdrawals are processed within 5-10 minutes</div>
                    <div>• Network fees may apply</div>
                  </div>
                  
                  <Button 
                    onClick={handleWithdraw}
                    disabled={withdrawMutation.isPending || !withdrawAmount || !withdrawAddress}
                    className="w-full bg-red-600 hover:bg-red-700"
                  >
                    <Minus className="w-4 h-4 mr-2" />
                    {withdrawMutation.isPending ? "Processing..." : "Confirm Withdrawal"}
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Security Notice */}
          <div className="text-xs text-gray-400 text-center flex items-center justify-center space-x-1">
            <Shield className="w-3 h-3" />
            <span>Secured by TON Blockchain • 3% house fee applies</span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
