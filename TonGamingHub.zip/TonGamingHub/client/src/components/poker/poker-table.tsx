import { useState } from "react";
import { PlayerPosition } from "./player-position";
import { ActionButtons } from "./action-buttons";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";

interface PokerTableProps {
  gameState: any;
  currentUser: { id: string; name: string };
  onPlayerAction: (action: string, amount?: number) => void;
  isConnected: boolean;
}

export function PokerTable({ gameState, currentUser, onPlayerAction, isConnected }: PokerTableProps) {
  const [betAmount, setBetAmount] = useState(25);
  const [showBettingSlider, setShowBettingSlider] = useState(false);

  const mockGameState = {
    pot: 125.40,
    communityCards: [
      { rank: 'A', suit: '♠' },
      { rank: 'K', suit: '♥' },
      { rank: 'Q', suit: '♦' },
    ],
    players: [
      {
        id: currentUser.id,
        name: currentUser.name,
        position: 0,
        chipCount: 1250,
        holeCards: [{ rank: 'A', suit: '♠' }, { rank: 'K', suit: '♠' }],
        isCurrentPlayer: true,
        status: 'active'
      },
      {
        id: 'player2',
        name: 'CryptoKing',
        position: 1,
        chipCount: 890.50,
        holeCards: [],
        isCurrentPlayer: false,
        status: 'thinking'
      },
      {
        id: 'player3',
        name: 'PokerAce',
        position: 2,
        chipCount: 1450.25,
        holeCards: [],
        isCurrentPlayer: false,
        status: 'active'
      },
      {
        id: 'player4',
        name: 'BluffMaster',
        position: 3,
        chipCount: 675.80,
        holeCards: [],
        isCurrentPlayer: false,
        status: 'folded'
      },
      {
        id: 'player5',
        name: 'ChipLeader',
        position: 4,
        chipCount: 2100,
        holeCards: [],
        isCurrentPlayer: false,
        status: 'all_in'
      }
    ],
    currentBet: 25,
    dealerPosition: 0
  };

  const currentGameState = gameState || mockGameState;
  const currentPlayer = currentGameState.players.find((p: any) => p.id === currentUser.id);
  const maxBet = currentPlayer ? currentPlayer.chipCount : 1000;

  const handleAction = (action: string) => {
    if (action === 'raise') {
      setShowBettingSlider(true);
      return;
    }
    
    setShowBettingSlider(false);
    
    if (action === 'call') {
      onPlayerAction(action, currentGameState.currentBet);
    } else if (action === 'bet') {
      onPlayerAction('raise', betAmount);
    } else {
      onPlayerAction(action);
    }
  };

  const handleBetSubmit = () => {
    onPlayerAction('raise', betAmount);
    setShowBettingSlider(false);
  };

  // Get poker chips display for pot
  const getChipsDisplay = (amount: number) => {
    const chips = [];
    if (amount >= 100) chips.push({ color: 'bg-chip-black', value: 100, count: Math.floor(amount / 100) });
    if (amount >= 25) chips.push({ color: 'bg-chip-green', value: 25, count: Math.floor((amount % 100) / 25) });
    if (amount >= 10) chips.push({ color: 'bg-chip-blue', value: 10, count: Math.floor((amount % 25) / 10) });
    if (amount >= 5) chips.push({ color: 'bg-chip-red', value: 5, count: Math.floor((amount % 10) / 5) });
    return chips;
  };

  return (
    <div className="flex-1 flex items-center justify-center p-8 relative min-h-[600px]">
      {/* Connection Status */}
      {!isConnected && (
        <div className="absolute top-4 right-4 z-10">
          <Badge variant="destructive">Disconnected</Badge>
        </div>
      )}

      {/* Poker Table */}
      <div className="poker-table relative w-[900px] h-[600px] rounded-full flex items-center justify-center">
        
        {/* Center Area - Community Cards & Pot */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            {/* Community Cards */}
            <div className="flex space-x-2 mb-6 justify-center">
              {currentGameState.communityCards.map((card: any, index: number) => (
                <div key={index} className="card w-16 h-24 flex items-center justify-center text-black font-bold animate-card-flip text-lg">
                  {card.rank}{card.suit}
                </div>
              ))}
              {/* Placeholder cards for turn and river */}
              {Array.from({ length: 5 - currentGameState.communityCards.length }).map((_, index) => (
                <div key={`placeholder-${index}`} className="card-back w-16 h-24 opacity-30 rounded-lg border-2 border-dashed border-gray-600">
                </div>
              ))}
            </div>
            
            {/* Pot Information */}
            <Card className="bg-black/70 border-poker-gold/20 backdrop-blur-sm">
              <div className="px-6 py-3">
                <div className="text-poker-gold font-bold text-lg pot-glow">
                  {currentGameState.pot.toFixed(2)} TON
                </div>
                <div className="text-gray-300 text-sm">Total Pot</div>
              </div>
            </Card>
            
            {/* Chips Visualization */}
            <div className="flex justify-center space-x-1 mt-4">
              {getChipsDisplay(currentGameState.pot).map((chip, index) => (
                <div key={index} className="flex flex-col items-center">
                  {Array.from({ length: Math.min(chip.count, 5) }).map((_, i) => (
                    <div 
                      key={i} 
                      className={`chip w-8 h-8 rounded-full ${chip.color} flex items-center justify-center text-white text-xs font-bold animate-chip-stack border-2 border-white/20 ${i > 0 ? '-mt-6' : ''}`}
                      style={{
                        zIndex: 10 - i,
                        animationDelay: `${i * 0.1}s`
                      }}
                    >
                      {chip.value}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Player Positions */}
        {currentGameState.players.map((player: any) => (
          <PlayerPosition
            key={player.id}
            player={player}
            isCurrentUser={player.id === currentUser.id}
            dealerPosition={currentGameState.dealerPosition}
          />
        ))}

        {/* Empty Seats */}
        {Array.from({ length: 8 - currentGameState.players.length }).map((_, index) => (
          <div 
            key={`empty-${index}`} 
            className={`absolute rounded-lg p-3 opacity-50 ${getPositionStyles(currentGameState.players.length + index)}`}
          >
            <div className="text-center">
              <div className="w-12 h-12 rounded-full mx-auto mb-2 border-2 border-dashed border-gray-600 flex items-center justify-center">
                <span className="text-gray-600 text-lg">+</span>
              </div>
              <Card className="bg-black/50 border-gray-600">
                <div className="px-2 py-1">
                  <div className="text-gray-500 text-xs">Empty Seat</div>
                  <button className="text-poker-gold text-xs hover:text-poker-orange transition-colors">
                    Join
                  </button>
                </div>
              </Card>
            </div>
          </div>
        ))}

        {/* Dealer Button */}
        <div className="absolute top-20 left-1/3 w-8 h-8 bg-poker-gold rounded-full flex items-center justify-center text-black font-bold text-sm shadow-lg">
          D
        </div>

        {/* Betting Slider */}
        {showBettingSlider && (
          <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 w-80 bg-black/90 rounded-lg p-4 glass-effect border border-poker-gold/30">
            <div className="text-center mb-3">
              <span className="text-poker-gold font-semibold">Bet Amount: </span>
              <span className="text-white font-mono text-lg">{betAmount.toFixed(2)} TON</span>
            </div>
            <Slider
              value={[betAmount]}
              onValueChange={(value) => setBetAmount(value[0])}
              max={maxBet}
              min={currentGameState.currentBet || 1}
              step={1}
              className="w-full mb-4"
            />
            <div className="flex justify-between text-xs text-gray-400 mb-4">
              <span>{currentGameState.currentBet || 1} TON</span>
              <span>{maxBet.toFixed(0)} TON</span>
            </div>
            <div className="flex space-x-2">
              <button 
                onClick={() => setShowBettingSlider(false)}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 rounded transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleBetSubmit}
                className="flex-1 bg-poker-gold hover:bg-poker-orange text-black py-2 rounded font-semibold transition-colors"
              >
                Bet {betAmount.toFixed(2)} TON
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      {currentPlayer?.isCurrentPlayer && !showBettingSlider && (
        <ActionButtons
          onAction={handleAction}
          currentBet={currentGameState.currentBet}
          playerChips={currentPlayer.chipCount}
          canCheck={currentPlayer.currentBet === currentGameState.currentBet}
        />
      )}
    </div>
  );
}

// Helper function to get position styles for players around the table
function getPositionStyles(position: number): string {
  const positions = [
    "bottom-4 left-1/2 transform -translate-x-1/2", // Bottom (current user)
    "bottom-8 left-8", // Bottom Left
    "left-4 top-1/2 transform -translate-y-1/2", // Left
    "top-8 left-8", // Top Left
    "top-4 left-1/2 transform -translate-x-1/2", // Top
    "top-8 right-8", // Top Right
    "right-4 top-1/2 transform -translate-y-1/2", // Right
    "bottom-8 right-8" // Bottom Right
  ];
  return positions[position % 8] || positions[0];
}
