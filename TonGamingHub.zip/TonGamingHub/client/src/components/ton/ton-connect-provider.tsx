import React from 'react';
import { TonConnectUIProvider } from '@tonconnect/ui-react';

const manifestUrl = `${window.location.origin}/tonconnect-manifest.json`;

interface TonConnectProviderProps {
  children: React.ReactNode;
}

export const TonConnectProvider: React.FC<TonConnectProviderProps> = ({ children }) => {
  return (
    <TonConnectUIProvider 
      manifestUrl={manifestUrl}
      uiPreferences={{ theme: 'SYSTEM' }}
      walletsListConfiguration={{
        includeWallets: []
      }}
    >
      {children}
    </TonConnectUIProvider>
  );
};

export default TonConnectProvider;