import React from 'react';
import { TonConnectButton, useTonConnectUI, useTonWallet } from '@tonconnect/ui-react';
import { Button } from '@/components/ui/button';
import { Wallet, LogOut, Copy, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

export const WalletConnector: React.FC = () => {
  const [tonConnectUI] = useTonConnectUI();
  const wallet = useTonWallet();
  const { toast } = useToast();

  const handleDisconnect = async () => {
    try {
      await tonConnectUI.disconnect();
      toast({
        title: "Wallet disconnesso",
        description: "Il tuo wallet TON è stato disconnesso con successo.",
      });
    } catch (error) {
      toast({
        title: "Errore",
        description: "Si è verificato un errore durante la disconnessione.",
        variant: "destructive",
      });
    }
  };

  const copyAddress = async () => {
    if (wallet?.account?.address) {
      try {
        await navigator.clipboard.writeText(wallet.account.address);
        toast({
          title: "Indirizzo copiato",
          description: "L'indirizzo del wallet è stato copiato negli appunti.",
        });
      } catch (error) {
        toast({
          title: "Errore",
          description: "Impossibile copiare l'indirizzo.",
          variant: "destructive",
        });
      }
    }
  };

  const openInExplorer = () => {
    if (wallet?.account?.address) {
      const explorerUrl = `https://tonviewer.com/${wallet.account.address}`;
      window.open(explorerUrl, '_blank');
    }
  };

  if (!wallet) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2">
            <Wallet className="w-5 h-5" />
            Connetti Wallet TON
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground text-center">
            Connetti il tuo wallet TON per iniziare a giocare con criptovalute reali.
          </p>
          <div className="flex justify-center">
            <TonConnectButton className="ton-connect-button" />
          </div>
          <div className="text-xs text-muted-foreground space-y-1">
            <p>• Wallet supportati: TonKeeper, Tonhub, OpenMask</p>
            <p>• Connessione sicura tramite TonConnect</p>
            <p>• Nessuna commissione di connessione</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Wallet className="w-5 h-5" />
            Wallet Connesso
          </span>
          <Badge className="bg-green-100 text-green-800">
            Attivo
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <p className="text-sm font-medium">Wallet: {wallet.device?.appName}</p>
          <div className="flex items-center gap-2">
            <p className="text-xs text-muted-foreground font-mono bg-muted px-2 py-1 rounded flex-1 truncate">
              {wallet.account?.address}
            </p>
            <Button variant="ghost" size="sm" onClick={copyAddress}>
              <Copy className="w-3 h-3" />
            </Button>
            <Button variant="ghost" size="sm" onClick={openInExplorer}>
              <ExternalLink className="w-3 h-3" />
            </Button>
          </div>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="flex-1" onClick={handleDisconnect}>
            <LogOut className="w-4 h-4 mr-1" />
            Disconnetti
          </Button>
        </div>

        <div className="text-xs text-muted-foreground space-y-1">
          <p>• Connessione sicura e crittografata</p>
          <p>• Le transazioni richiedono conferma dal wallet</p>
          <p>• Puoi disconnetterti in qualsiasi momento</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default WalletConnector;