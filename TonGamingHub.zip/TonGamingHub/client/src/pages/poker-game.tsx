import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/use-websocket";
import { useTonWallet } from "@tonconnect/ui-react";
import { PokerTable } from "@/components/poker/poker-table";
import { GameChat } from "@/components/poker/game-chat";
import { WalletModal } from "@/components/poker/wallet-modal";
import { TournamentLobby } from "@/components/poker/tournament-lobby";
import { MobileWalletIntegration } from "@/components/poker/mobile-wallet-integration";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Coins, Wallet, LogOut, Users } from "lucide-react";

export default function PokerGame() {
  const [currentUser] = useState({ id: "user123", name: "Player1" }); // Mock user
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isTournamentModalOpen, setIsTournamentModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // WebSocket connection for real-time updates
  const { 
    gameState, 
    isConnected, 
    sendMessage,
    joinGame,
    leaveGame 
  } = useWebSocket();

  // TON wallet integration via TonConnect
  const wallet = useTonWallet();

  // Fetch user data
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['/api/user', currentUser.id],
    enabled: !!currentUser.id
  });

  // Fetch available tables
  const { data: tables, isLoading: tablesLoading } = useQuery({
    queryKey: ['/api/tables']
  });

  // Join table mutation
  const joinTableMutation = useMutation({
    mutationFn: async ({ tableId, chipCount }: { tableId: string; chipCount: number }) => {
      const response = await apiRequest('POST', `/api/games/${tableId}/join`, {
        userId: currentUser.id,
        chipCount
      });
      return response.json();
    },
    onSuccess: (data) => {
      setSelectedTable(data.gameId);
      joinGame(data.gameId, currentUser.id);
      toast({
        title: "Joined Table",
        description: "You have successfully joined the poker table."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Join",
        description: error.message || "Could not join the table.",
        variant: "destructive"
      });
    }
  });

  // Player action mutation
  const playerActionMutation = useMutation({
    mutationFn: async ({ action, amount }: { action: string; amount?: number }) => {
      if (!selectedTable) throw new Error("No table selected");
      
      const response = await apiRequest('POST', `/api/games/${selectedTable}/action`, {
        userId: currentUser.id,
        action,
        amount
      });
      return response.json();
    },
    onError: (error: any) => {
      toast({
        title: "Action Failed",
        description: error.message || "Could not process your action.",
        variant: "destructive"
      });
    }
  });

  const handleJoinTable = (tableId: string, chipCount: number) => {
    if (!user || parseFloat(user.balance) < chipCount) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough TON to join this table.",
        variant: "destructive"
      });
      return;
    }
    
    joinTableMutation.mutate({ tableId, chipCount });
  };

  const handlePlayerAction = (action: string, amount?: number) => {
    playerActionMutation.mutate({ action, amount });
  };

  const handleLeaveTable = () => {
    if (selectedTable) {
      leaveGame(selectedTable);
      setSelectedTable(null);
      queryClient.invalidateQueries({ queryKey: ['/api/user', currentUser.id] });
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-poker-dark flex items-center justify-center">
        <div className="text-poker-gold text-xl">Loading poker table...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-poker-dark text-white flex flex-col relative">
      {/* Header */}
      <header className="bg-gradient-to-r from-gray-900 to-gray-800 border-b border-gray-700 px-6 py-4 flex justify-between items-center z-20">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Coins className="text-poker-gold text-2xl" />
            <h1 className="text-2xl font-bold text-poker-gold">TON Poker Pro</h1>
          </div>
          {selectedTable && (
            <div className="text-sm text-gray-300">
              Table: High Stakes | Blinds: <span className="text-poker-gold font-mono">0.1/0.2 TON</span>
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-6">
          {/* User Balance */}
          <div className="flex items-center space-x-2 bg-gray-800 px-4 py-2 rounded-lg">
            <Coins className="text-poker-gold w-4 h-4" />
            <span className="font-mono">{user?.balance || "0.00"}</span>
            <span className="text-poker-gold">TON</span>
          </div>
          
          {/* Mobile Wallet Integration */}
          <MobileWalletIntegration 
            userBalance={parseFloat(user?.balance || "0")}
            onBalanceUpdate={(newBalance) => {
              queryClient.invalidateQueries({ queryKey: ['/api/user', currentUser.id] });
            }}
          />
          
          {/* Tournament Lobby Button */}
          {!selectedTable && (
            <Button 
              onClick={() => setIsTournamentModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Users className="w-4 h-4 mr-2" />
              Tables
            </Button>
          )}
          
          {/* Leave Table Button */}
          {selectedTable && (
            <Button 
              onClick={handleLeaveTable}
              className="bg-red-600 hover:bg-red-700"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Leave Table
            </Button>
          )}
        </div>
      </header>

      {/* Main Game Area */}
      <div className="flex-1 flex relative">
        {selectedTable ? (
          <>
            {/* Poker Table */}
            <main className="flex-1">
              <PokerTable 
                gameState={gameState}
                currentUser={currentUser}
                onPlayerAction={handlePlayerAction}
                isConnected={isConnected}
              />
            </main>
            
            {/* Chat Sidebar */}
            <aside className="w-80 bg-gray-900 border-l border-gray-700">
              <GameChat 
                gameId={selectedTable}
                currentUser={currentUser}
                gameState={gameState}
              />
            </aside>
          </>
        ) : (
          /* Table Selection Screen */
          <main className="flex-1 flex items-center justify-center p-8">
            <Card className="w-full max-w-4xl">
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-poker-gold mb-4">Welcome to TON Poker Pro</h2>
                  <p className="text-gray-300 text-lg">Choose a table to start playing professional poker with TON cryptocurrency</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {tablesLoading ? (
                    <div className="col-span-full text-center text-gray-400">Loading tables...</div>
                  ) : tables && tables.length > 0 ? (
                    tables.map((table: any) => (
                      <Card key={table.id} className="bg-gray-800 border-gray-600 hover:border-poker-gold transition-colors cursor-pointer">
                        <CardContent className="p-6">
                          <h3 className="text-xl font-semibold text-white mb-2">{table.name}</h3>
                          <div className="space-y-2 text-sm text-gray-300">
                            <div className="flex justify-between">
                              <span>Blinds:</span>
                              <span className="text-poker-gold font-mono">{table.smallBlind}/{table.bigBlind} TON</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Players:</span>
                              <span className="text-white">{table.currentPlayers}/{table.maxPlayers}</span>
                            </div>
                          </div>
                          <Button 
                            onClick={() => handleJoinTable(table.id, parseFloat(table.bigBlind) * 50)}
                            className="w-full mt-4 bg-poker-gold text-black hover:bg-poker-orange"
                            disabled={joinTableMutation.isPending || table.currentPlayers >= table.maxPlayers}
                          >
                            {joinTableMutation.isPending ? "Joining..." : "Join Table"}
                          </Button>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="col-span-full text-center">
                      <p className="text-gray-400 mb-4">No active tables found</p>
                      <Button 
                        onClick={() => setIsTournamentModalOpen(true)}
                        className="bg-poker-gold text-black hover:bg-poker-orange"
                      >
                        Create New Table
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </main>
        )}
      </div>

      {/* Tournament Lobby Modal */}
      <TournamentLobby 
        isOpen={isTournamentModalOpen}
        onClose={() => setIsTournamentModalOpen(false)}
        tables={tables || []}
        onJoinTable={handleJoinTable}
        currentUser={currentUser}
      />
    </div>
  );
}
