import { useEffect, useState } from 'react';
import { useTonConnectUI, useTonWallet } from '@tonconnect/ui-react';

export interface TonTransaction {
  to: string;
  value: string;
  data?: string;
  stateInit?: string;
}

export const useTonConnect = () => {
  const [tonConnectUI] = useTonConnectUI();
  const wallet = useTonWallet();
  const [isLoading, setIsLoading] = useState(false);
  const [balance, setBalance] = useState<string | null>(null);

  // Fee wallet address per ricevere commissioni di gioco
  const FEE_WALLET = 'UQBGvXxhIN2vZXjOM4pzwO6CQF-Ak3AqGqpCqcsAUB8cxw76';
  // Earnings address per vincite e depositi
  const EARNINGS_ADDRESS = '9f22bccb015b9062e7455ec80bbe70814b559f2ad5343f210cf13a9378da3bd7';

  const isConnected = !!wallet;
  const userAddress = wallet?.account?.address;

  // Fetch wallet balance
  useEffect(() => {
    const fetchBalance = async () => {
      if (!userAddress) {
        setBalance(null);
        return;
      }

      try {
        // Simulated balance for demo - in production would fetch from TON API
        setBalance('1000.5');
      } catch (error) {
        console.error('Error fetching balance:', error);
        setBalance(null);
      }
    };

    fetchBalance();
  }, [userAddress]);

  const sendTransaction = async (transaction: TonTransaction) => {
    if (!tonConnectUI || !wallet) {
      throw new Error('Wallet not connected');
    }

    setIsLoading(true);
    try {
      const result = await tonConnectUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 60, // Valid for 60 seconds
        messages: [
          {
            address: transaction.to,
            amount: transaction.value,
            payload: transaction.data,
            stateInit: transaction.stateInit,
          },
        ],
      });

      return result;
    } catch (error) {
      console.error('Transaction failed:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const deposit = async (amount: number) => {
    if (!userAddress) {
      throw new Error('Wallet not connected');
    }

    const tonAmount = (amount * 1000000000).toString(); // Convert to nanotons
    
    return await sendTransaction({
      to: EARNINGS_ADDRESS,
      value: tonAmount,
      data: `deposit:${userAddress}`,
    });
  };

  const withdraw = async (amount: number, toAddress: string) => {
    if (!userAddress) {
      throw new Error('Wallet not connected');
    }

    // In a real implementation, this would trigger a backend process
    // to send TON from the earnings wallet to the user's withdrawal address
    console.log(`Withdrawal request: ${amount} TON to ${toAddress}`);
    
    // For now, we simulate the withdrawal
    return {
      boc: 'simulated_withdrawal_boc',
      hash: 'simulated_withdrawal_hash'
    };
  };

  const payHouseFee = async (amount: number, gameId: string) => {
    if (!userAddress) {
      throw new Error('Wallet not connected');
    }

    const feeAmount = (amount * 1000000000).toString(); // Convert to nanotons
    
    return await sendTransaction({
      to: FEE_WALLET,
      value: feeAmount,
      data: `house_fee:${gameId}:${userAddress}`,
    });
  };

  const placeBet = async (amount: number, gameId: string) => {
    if (!userAddress) {
      throw new Error('Wallet not connected');
    }

    const betAmount = (amount * 1000000000).toString(); // Convert to nanotons
    
    return await sendTransaction({
      to: EARNINGS_ADDRESS,
      value: betAmount,
      data: `bet:${gameId}:${userAddress}`,
    });
  };

  const disconnect = async () => {
    if (tonConnectUI) {
      await tonConnectUI.disconnect();
      setBalance(null);
    }
  };

  return {
    // Connection state
    isConnected,
    wallet,
    userAddress,
    balance,
    isLoading,

    // Actions
    sendTransaction,
    deposit,
    withdraw,
    payHouseFee,
    placeBet,
    disconnect,

    // Configuration
    feeWallet: FEE_WALLET,
    earningsAddress: EARNINGS_ADDRESS,
  };
};

export default useTonConnect;