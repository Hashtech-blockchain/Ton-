export interface Card {
  rank: string;
  suit: string;
}

export interface HandResult {
  strength: number;
  description: string;
  cards: Card[];
}

// Card rank values for comparison
const RANK_VALUES: { [key: string]: number } = {
  '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
  'J': 11, 'Q': 12, 'K': 13, 'A': 14
};

// Hand strength rankings (higher = better)
export const HAND_RANKINGS = {
  HIGH_CARD: 0,
  ONE_PAIR: 1,
  TWO_PAIR: 2,
  THREE_OF_A_KIND: 3,
  STRAIGHT: 4,
  FLUSH: 5,
  FULL_HOUSE: 6,
  FOUR_OF_A_KIND: 7,
  STRAIGHT_FLUSH: 8,
  ROYAL_FLUSH: 9
};

/**
 * Get the numeric value of a card rank
 */
export function getCardValue(rank: string): number {
  return RANK_VALUES[rank] || 0;
}

/**
 * Check if cards form a flush (all same suit)
 */
export function isFlush(cards: Card[]): boolean {
  if (cards.length < 5) return false;
  const suit = cards[0].suit;
  return cards.slice(0, 5).every(card => card.suit === suit);
}

/**
 * Check if cards form a straight (consecutive ranks)
 */
export function isStraight(cards: Card[]): boolean {
  if (cards.length < 5) return false;
  
  const values = cards.slice(0, 5).map(card => getCardValue(card.rank)).sort((a, b) => a - b);
  
  // Check for regular straight
  for (let i = 1; i < values.length; i++) {
    if (values[i] !== values[i-1] + 1) {
      return false;
    }
  }
  
  return true;
}

/**
 * Check for low straight (A-2-3-4-5)
 */
export function isLowStraight(cards: Card[]): boolean {
  if (cards.length < 5) return false;
  
  const ranks = cards.slice(0, 5).map(card => card.rank).sort();
  return JSON.stringify(ranks) === JSON.stringify(['2', '3', '4', '5', 'A']);
}

/**
 * Count occurrences of each rank
 */
export function getRankCounts(cards: Card[]): { [rank: string]: number } {
  const counts: { [rank: string]: number } = {};
  cards.forEach(card => {
    counts[card.rank] = (counts[card.rank] || 0) + 1;
  });
  return counts;
}

/**
 * Evaluate the best 5-card poker hand from 7 cards
 */
export function evaluateHand(cards: Card[]): HandResult {
  if (cards.length < 5) {
    return {
      strength: HAND_RANKINGS.HIGH_CARD,
      description: 'High Card',
      cards: cards.slice(0, 5)
    };
  }

  // Sort cards by rank value (descending)
  const sortedCards = [...cards].sort((a, b) => getCardValue(b.rank) - getCardValue(a.rank));
  
  // Get all possible 5-card combinations
  const combinations = getAllCombinations(sortedCards, 5);
  
  let bestHand: HandResult = {
    strength: -1,
    description: '',
    cards: []
  };

  // Evaluate each combination
  combinations.forEach(combo => {
    const hand = evaluateFiveCardHand(combo);
    if (hand.strength > bestHand.strength) {
      bestHand = hand;
    }
  });

  return bestHand;
}

/**
 * Get all combinations of k cards from n cards
 */
function getAllCombinations(cards: Card[], k: number): Card[][] {
  if (k === 1) return cards.map(card => [card]);
  if (k === cards.length) return [cards];
  if (k > cards.length) return [];

  const combinations: Card[][] = [];
  
  for (let i = 0; i <= cards.length - k; i++) {
    const head = cards[i];
    const tailCombos = getAllCombinations(cards.slice(i + 1), k - 1);
    
    tailCombos.forEach(combo => {
      combinations.push([head, ...combo]);
    });
  }
  
  return combinations;
}

/**
 * Evaluate a specific 5-card hand
 */
function evaluateFiveCardHand(cards: Card[]): HandResult {
  const sortedCards = [...cards].sort((a, b) => getCardValue(b.rank) - getCardValue(a.rank));
  const rankCounts = getRankCounts(sortedCards);
  const counts = Object.values(rankCounts).sort((a, b) => b - a);
  
  const isFlushHand = isFlush(sortedCards);
  const isStraightHand = isStraight(sortedCards) || isLowStraight(sortedCards);

  // Royal Flush (A-K-Q-J-10 of same suit)
  if (isFlushHand && isStraightHand && getCardValue(sortedCards[0].rank) === 14) {
    return {
      strength: HAND_RANKINGS.ROYAL_FLUSH,
      description: 'Royal Flush',
      cards: sortedCards
    };
  }

  // Straight Flush
  if (isFlushHand && isStraightHand) {
    return {
      strength: HAND_RANKINGS.STRAIGHT_FLUSH,
      description: 'Straight Flush',
      cards: sortedCards
    };
  }

  // Four of a Kind
  if (counts[0] === 4) {
    return {
      strength: HAND_RANKINGS.FOUR_OF_A_KIND,
      description: 'Four of a Kind',
      cards: sortedCards
    };
  }

  // Full House
  if (counts[0] === 3 && counts[1] === 2) {
    return {
      strength: HAND_RANKINGS.FULL_HOUSE,
      description: 'Full House',
      cards: sortedCards
    };
  }

  // Flush
  if (isFlushHand) {
    return {
      strength: HAND_RANKINGS.FLUSH,
      description: 'Flush',
      cards: sortedCards
    };
  }

  // Straight
  if (isStraightHand) {
    return {
      strength: HAND_RANKINGS.STRAIGHT,
      description: 'Straight',
      cards: sortedCards
    };
  }

  // Three of a Kind
  if (counts[0] === 3) {
    return {
      strength: HAND_RANKINGS.THREE_OF_A_KIND,
      description: 'Three of a Kind',
      cards: sortedCards
    };
  }

  // Two Pair
  if (counts[0] === 2 && counts[1] === 2) {
    return {
      strength: HAND_RANKINGS.TWO_PAIR,
      description: 'Two Pair',
      cards: sortedCards
    };
  }

  // One Pair
  if (counts[0] === 2) {
    return {
      strength: HAND_RANKINGS.ONE_PAIR,
      description: 'One Pair',
      cards: sortedCards
    };
  }

  // High Card
  return {
    strength: HAND_RANKINGS.HIGH_CARD,
    description: 'High Card',
    cards: sortedCards
  };
}

/**
 * Format currency amount for display
 */
export function formatCurrency(amount: number | string, currency: string = 'TON'): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : amount;
  return `${num.toLocaleString(undefined, { 
    minimumFractionDigits: 2, 
    maximumFractionDigits: 2 
  })} ${currency}`;
}

/**
 * Calculate pot odds
 */
export function calculatePotOdds(potSize: number, betSize: number): number {
  return betSize / (potSize + betSize);
}

/**
 * Generate a standard 52-card deck
 */
export function createDeck(): Card[] {
  const suits = ['♠', '♥', '♦', '♣'];
  const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
  const deck: Card[] = [];

  suits.forEach(suit => {
    ranks.forEach(rank => {
      deck.push({ rank, suit });
    });
  });

  return deck;
}

/**
 * Shuffle an array using Fisher-Yates algorithm
 */
export function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

/**
 * Get card display string
 */
export function getCardDisplay(card: Card): string {
  return `${card.rank}${card.suit}`;
}

/**
 * Check if a hand is a premium starting hand in Texas Hold'em
 */
export function isPremiumStartingHand(cards: Card[]): boolean {
  if (cards.length !== 2) return false;
  
  const [card1, card2] = cards;
  const rank1 = card1.rank;
  const rank2 = card2.rank;
  const suited = card1.suit === card2.suit;
  
  // Pocket pairs
  if (rank1 === rank2) {
    return ['A', 'K', 'Q', 'J', '10', '9'].includes(rank1);
  }
  
  // Premium suited hands
  if (suited) {
    const premiumSuited = [
      ['A', 'K'], ['A', 'Q'], ['A', 'J'], ['A', '10'],
      ['K', 'Q'], ['K', 'J'], ['Q', 'J']
    ];
    
    return premiumSuited.some(([r1, r2]) => 
      (rank1 === r1 && rank2 === r2) || (rank1 === r2 && rank2 === r1)
    );
  }
  
  // Premium offsuit hands
  const premiumOffsuit = [
    ['A', 'K'], ['A', 'Q'], ['A', 'J'],
    ['K', 'Q'], ['K', 'J']
  ];
  
  return premiumOffsuit.some(([r1, r2]) => 
    (rank1 === r1 && rank2 === r2) || (rank1 === r2 && rank2 === r1)
  );
}
