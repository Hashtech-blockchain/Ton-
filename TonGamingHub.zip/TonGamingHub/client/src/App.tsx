import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TonConnectProvider } from "@/components/ton/ton-connect-provider";
import NotFound from "@/pages/not-found";
import PokerGame from "@/pages/poker-game";

function Router() {
  return (
    <Switch>
      <Route path="/" component={PokerGame} />
      <Route path="/poker" component={PokerGame} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TonConnectProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </TonConnectProvider>
    </QueryClientProvider>
  );
}

export default App;
