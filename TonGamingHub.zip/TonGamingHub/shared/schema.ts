import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  tonWalletAddress: text("ton_wallet_address"),
  balance: decimal("balance", { precision: 18, scale: 8 }).default("0"),
  totalDeposited: decimal("total_deposited", { precision: 18, scale: 8 }).default("0"),
  totalWithdrawn: decimal("total_withdrawn", { precision: 18, scale: 8 }).default("0"),
  gamesPlayed: integer("games_played").default(0),
  handsWon: integer("hands_won").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  lastActiveAt: timestamp("last_active_at").defaultNow(),
  isActive: boolean("is_active").default(true)
});

export const pokerTables = pgTable("poker_tables", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  maxPlayers: integer("max_players").default(8),
  smallBlind: decimal("small_blind", { precision: 18, scale: 8 }).notNull(),
  bigBlind: decimal("big_blind", { precision: 18, scale: 8 }).notNull(),
  currentPlayers: integer("current_players").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: varchar("created_by").references(() => users.id)
});

export const pokerGames = pgTable("poker_games", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tableId: varchar("table_id").references(() => pokerTables.id).notNull(),
  handNumber: integer("hand_number").notNull(),
  dealerId: varchar("dealer_id").references(() => users.id),
  smallBlindId: varchar("small_blind_id").references(() => users.id),
  bigBlindId: varchar("big_blind_id").references(() => users.id),
  communityCards: jsonb("community_cards").default('[]'),
  pot: decimal("pot", { precision: 18, scale: 8 }).default("0"),
  houseFee: decimal("house_fee", { precision: 18, scale: 8 }).default("0"),
  gameState: text("game_state").default("waiting"), // waiting, preflop, flop, turn, river, showdown, finished
  currentPlayerId: varchar("current_player_id").references(() => users.id),
  startedAt: timestamp("started_at").defaultNow(),
  finishedAt: timestamp("finished_at"),
  winnerId: varchar("winner_id").references(() => users.id),
  winningHand: text("winning_hand")
});

export const gameParticipants = pgTable("game_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => pokerGames.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  position: integer("position").notNull(), // 0-7 for table positions
  chipCount: decimal("chip_count", { precision: 18, scale: 8 }).notNull(),
  initialChips: decimal("initial_chips", { precision: 18, scale: 8 }).notNull(),
  holeCards: jsonb("hole_cards").default('[]'),
  currentBet: decimal("current_bet", { precision: 18, scale: 8 }).default("0"),
  totalBet: decimal("total_bet", { precision: 18, scale: 8 }).default("0"),
  hasActed: boolean("has_acted").default(false),
  hasFolded: boolean("has_folded").default(false),
  isAllIn: boolean("is_all_in").default(false),
  joinedAt: timestamp("joined_at").defaultNow(),
  leftAt: timestamp("left_at")
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  gameId: varchar("game_id").references(() => pokerGames.id),
  type: text("type").notNull(), // deposit, withdrawal, bet, win, fee
  amount: decimal("amount", { precision: 18, scale: 8 }).notNull(),
  tonTxHash: text("ton_tx_hash"),
  status: text("status").default("pending"), // pending, confirmed, failed
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  confirmedAt: timestamp("confirmed_at")
});

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => pokerGames.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  message: text("message").notNull(),
  type: text("type").default("user"), // user, system, action
  createdAt: timestamp("created_at").defaultNow()
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  createdTables: many(pokerTables),
  gameParticipations: many(gameParticipants),
  transactions: many(transactions),
  chatMessages: many(chatMessages)
}));

export const pokerTablesRelations = relations(pokerTables, ({ one, many }) => ({
  creator: one(users, {
    fields: [pokerTables.createdBy],
    references: [users.id]
  }),
  games: many(pokerGames)
}));

export const pokerGamesRelations = relations(pokerGames, ({ one, many }) => ({
  table: one(pokerTables, {
    fields: [pokerGames.tableId],
    references: [pokerTables.id]
  }),
  dealer: one(users, {
    fields: [pokerGames.dealerId],
    references: [users.id]
  }),
  participants: many(gameParticipants),
  chatMessages: many(chatMessages)
}));

export const gameParticipantsRelations = relations(gameParticipants, ({ one }) => ({
  game: one(pokerGames, {
    fields: [gameParticipants.gameId],
    references: [pokerGames.id]
  }),
  user: one(users, {
    fields: [gameParticipants.userId],
    references: [users.id]
  })
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id]
  }),
  game: one(pokerGames, {
    fields: [transactions.gameId],
    references: [pokerGames.id]
  })
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  game: one(pokerGames, {
    fields: [chatMessages.gameId],
    references: [pokerGames.id]
  }),
  user: one(users, {
    fields: [chatMessages.userId],
    references: [users.id]
  })
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  tonWalletAddress: true
});

export const insertPokerTableSchema = createInsertSchema(pokerTables).pick({
  name: true,
  maxPlayers: true,
  smallBlind: true,
  bigBlind: true
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  type: true,
  amount: true,
  tonTxHash: true,
  description: true
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  message: true,
  type: true
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type PokerTable = typeof pokerTables.$inferSelect;
export type PokerGame = typeof pokerGames.$inferSelect;
export type GameParticipant = typeof gameParticipants.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertPokerTable = z.infer<typeof insertPokerTableSchema>;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

// Game state types
export type Card = {
  rank: string;
  suit: string;
};

export type GameState = 'waiting' | 'preflop' | 'flop' | 'turn' | 'river' | 'showdown' | 'finished';

export type PlayerAction = 'fold' | 'check' | 'call' | 'raise' | 'all_in';

export type PokerAction = {
  playerId: string;
  action: PlayerAction;
  amount?: string;
  timestamp: Date;
};
